# Radix Android Calculator

An Android calculator that operates in any positional numeral system.

![screenshot](screenshot.jpg)

## Download Link:

[Amazon Appstore](https://www.amazon.ca/Carson-Craig-The-Radix-Calculator/dp/B014IUXNNS)
